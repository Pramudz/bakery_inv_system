import { NavLink, Outlet, useLocation } from 'react-router-dom';
import './app.css';

const groups=[
 {title:'Overview',items:[['Dashboard','/']]},
 {title:'Organization',items:[['Tenants','/tenants'],['Users','/users'],['Roles','/roles'],['Permissions','/permissions']]},
 {title:'Product Master',items:[['Products','/products'],['Categories','/categories'],['Brands','/brands'],['Units','/units'],['Identifiers','/identifier-types'],['Attributes','/attributes']]},
 {title:'Supply & Pricing',items:[['Suppliers','/suppliers'],['Product Suppliers','/product-suppliers'],['Product Costing','/product-costing'],['Price Lists','/price-lists']]},
 {title:'Locations',items:[['Locations','/locations'],['Product Locations','/product-locations']]},
 {title:'System',items:[['Modules','/modules'],['User Roles','/user-roles'],['Role Permissions','/role-permissions'],['Sessions','/user-sessions']]},
];
export default function App(){
 const location=useLocation(); const title=groups.flatMap(g=>g.items).find(x=>x[1]===location.pathname)?.[0] ?? 'ERP';
 return <div className="shell"><aside className="sidebar"><div className="brand"><div className="brand-mark">E</div><div><b>ERP<span>Core</span></b><small>Enterprise Resource Platform</small></div></div><div className="tenant-pill"><span className="tenant-pulse"/><div><small>Current tenant</small><strong>Authenticated tenant</strong></div></div><nav>{groups.map(g=><div className="nav-group" key={g.title}><div className="nav-group-title">{g.title}</div>{g.items.map(([label,to])=><NavLink key={to} to={to} end={to==='/' } className={({isActive})=>isActive?'nav active':'nav'}><span className="nav-dot"/>{label}</NavLink>)}</div>)}</nav><div className="sidebar-foot"><span>●</span> Development environment</div></aside><main className="main"><header className="topbar"><div className="crumb"><span>ERP Core</span><b>/</b><strong>{title}</strong></div><div className="top-actions"><button className="icon-btn">⌕</button><button className="icon-btn">♧</button><div className="profile"><span className="avatar user-avatar">A</span><div><strong>Administrator</strong><small>System user</small></div><span>⌄</span></div></div></header><section className="content"><Outlet/></section></main></div>
}
