import { env } from '../config/env';

export class ApiError extends Error {
  constructor(public status:number, message:string, public details?:unknown) {
    super(message);
  }
}

async function request<T>(path:string, options:RequestInit={}):Promise<T> {
  const response = await fetch(`${env.apiUrl}${path}`, {
    ...options,
    headers: {'Content-Type':'application/json', ...(options.headers ?? {})},
  });

  const contentType = response.headers.get('content-type') ?? '';
  const body = contentType.includes('application/json')
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    const message = typeof body === 'object' && body?.message
      ? Array.isArray(body.message) ? body.message.join(', ') : body.message
      : `Request failed (${response.status})`;
    throw new ApiError(response.status, message, body);
  }

  return body as T;
}

export const apiClient = {
  get:<T>(path:string)=>request<T>(path),
  post:<T>(path:string,data:unknown)=>request<T>(path,{method:'POST',body:JSON.stringify(data)}),
  put:<T>(path:string,data:unknown)=>request<T>(path,{method:'PUT',body:JSON.stringify(data)}),
  patch:<T>(path:string,data?:unknown)=>request<T>(path,{method:'PATCH',body:data===undefined?undefined:JSON.stringify(data)}),
};
